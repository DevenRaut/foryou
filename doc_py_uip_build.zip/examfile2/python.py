a = input("enter the string : ")
print(a)
